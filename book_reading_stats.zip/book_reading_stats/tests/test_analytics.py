import unittest
from datetime import date

from brs import analytics
from brs.models import Book

SETTINGS = {"monthly_goal_books": 2, "monthly_goal_pages": 500}


def book(i, title, pages, day, rating=4, author="Author", genre="Fiction"):
    return Book(id=i, title=title, author=author, genre=genre, pages=pages, date_finished=day, rating=rating)


BOOKS = [
    book(1, "A", 100, "2026-01-10", 5, "Ann", "Fiction"),
    book(2, "B", 300, "2026-01-20", 3, "Ann", "Science"),
    book(3, "C", 200, "2026-03-05", 4, "Bob", "Fiction"),  # February has no books
]


class Monthly(unittest.TestCase):
    def test_gaps_filled_with_zero_rows(self):
        rows = analytics.monthly_totals(BOOKS)
        self.assertEqual([r["month"] for r in rows], ["2026-01", "2026-02", "2026-03"])
        self.assertEqual([r["books"] for r in rows], [2, 0, 1])
        self.assertEqual([r["pages"] for r in rows], [400, 0, 200])
        self.assertIsNone(rows[1]["avg_rating"])
        self.assertEqual(rows[0]["avg_rating"], 4.0)

    def test_year_rollover(self):
        rows = analytics.monthly_totals([book(1, "X", 10, "2025-12-31"), book(2, "Y", 10, "2026-02-01")])
        self.assertEqual([r["month"] for r in rows], ["2025-12", "2026-01", "2026-02"])

    def test_empty(self):
        self.assertEqual(analytics.monthly_totals([]), [])
        self.assertEqual(analytics.summary([]), {"total_books": 0})

    def test_goal_status(self):
        self.assertEqual(analytics.goal_status({"books": 2, "pages": 500}, SETTINGS), "GOAL MET")
        self.assertEqual(analytics.goal_status({"books": 2, "pages": 100}, SETTINGS), "PARTIAL")
        self.assertEqual(analytics.goal_status({"books": 0, "pages": 0}, SETTINGS), "BEHIND")


class Summary(unittest.TestCase):
    def test_totals(self):
        s = analytics.summary(BOOKS)
        self.assertEqual(s["total_books"], 3)
        self.assertEqual(s["total_pages"], 600)
        self.assertAlmostEqual(s["avg_pages"], 200)
        self.assertEqual(s["median_pages"], 200)
        self.assertAlmostEqual(s["avg_rating"], 4.0)
        self.assertEqual(s["longest"].title, "B")
        self.assertEqual(s["shortest"].title, "A")
        self.assertEqual(s["top_genre"]["genre"], "Fiction")
        self.assertEqual(s["top_author"]["author"], "Ann")
        self.assertEqual(s["months_tracked"], 3)
        self.assertEqual(s["best_month"]["month"], "2026-01")

    def test_genre_shares_sum_to_100(self):
        self.assertAlmostEqual(sum(g["share"] for g in analytics.genre_breakdown(BOOKS)), 100.0)

    def test_rating_distribution_has_all_stars(self):
        self.assertEqual(analytics.rating_distribution(BOOKS), {1: 0, 2: 0, 3: 1, 4: 1, 5: 1})


class Trend(unittest.TestCase):
    def test_needs_two_months(self):
        self.assertIsNone(analytics.trend([{"month": "2026-01", "books": 1, "pages": 10, "avg_rating": 4}]))

    def test_up_and_down(self):
        def rows(pages):
            return [{"month": f"2026-{i + 1:02d}", "books": 1, "pages": p, "avg_rating": 4} for i, p in enumerate(pages)]

        up = analytics.trend(rows([100, 200, 300, 400]))
        self.assertEqual(up["direction"], "up")
        self.assertEqual(up["change_pct"], 33.3)
        self.assertEqual(analytics.trend(rows([400, 300, 200, 100]))["direction"], "down")
        self.assertEqual(analytics.trend(rows([300, 300, 300]))["direction"], "flat")

    def test_previous_zero_has_no_percentage(self):
        t = analytics.trend([
            {"month": "2026-01", "books": 0, "pages": 0, "avg_rating": None},
            {"month": "2026-02", "books": 1, "pages": 50, "avg_rating": 4},
        ])
        self.assertIsNone(t["change_pct"])

    def test_in_progress_flag(self):
        rows = [{"month": "2026-10", "books": 1, "pages": 5, "avg_rating": 4},
                {"month": "2026-11", "books": 1, "pages": 5, "avg_rating": 4}]
        self.assertTrue(analytics.trend(rows, date(2026, 11, 23))["in_progress"])
        self.assertFalse(analytics.trend(rows, date(2026, 12, 2))["in_progress"])


class Search(unittest.TestCase):
    def test_filters(self):
        self.assertEqual([b.id for b in analytics.search(BOOKS, keyword="ann")], [1, 2])  # author match
        self.assertEqual([b.id for b in analytics.search(BOOKS, genre="fiction")], [1, 3])
        self.assertEqual([b.id for b in analytics.search(BOOKS, min_rating=4)], [1, 3])
        self.assertEqual([b.id for b in analytics.search(BOOKS, month="2026-01")], [1, 2])
        self.assertEqual([b.id for b in analytics.search(BOOKS, keyword="ann", genre="Science")], [2])
        self.assertEqual(analytics.search(BOOKS, keyword="zzz"), [])

    def test_no_filters_returns_everything(self):
        self.assertEqual(len(analytics.search(BOOKS)), 3)


class Alerts(unittest.TestCase):
    def msgs(self, books, today=date(2026, 3, 20)):
        return [a.message for a in analytics.warnings(books, SETTINGS, today)]

    def test_long_short_duplicate_same_day(self):
        books = [
            book(1, "Huge", 1500, "2026-03-01"),
            book(2, "Tiny", 3, "2026-03-02"),
            book(3, "Dup", 100, "2026-03-03", author="Z"),
            book(4, "dup", 100, "2026-03-04", author="z"),
        ] + [book(10 + i, f"Day{i}", 50, "2026-03-05") for i in range(4)]
        text = "\n".join(self.msgs(books))
        self.assertIn("Unusually long", text)
        self.assertIn("Unusually short", text)
        self.assertIn("Possible duplicate", text)
        self.assertIn("4 books finished on 2026-03-05", text)

    def test_inactivity(self):
        text = "\n".join(self.msgs(BOOKS, today=date(2026, 6, 1)))
        self.assertIn("No book logged for", text)

    def test_goal_behind_vs_met(self):
        behind = analytics.warnings([book(1, "A", 100, "2026-03-02")], SETTINGS, date(2026, 3, 20))
        self.assertTrue(any(a.level == "WARN" and "goal not met" in a.message for a in behind))
        self.assertIn("1 more book(s)", behind[0].message)
        met = analytics.warnings(
            [book(1, "A", 300, "2026-03-02"), book(2, "B", 300, "2026-03-03")], SETTINGS, date(2026, 3, 20)
        )
        self.assertEqual([a.level for a in met], ["INFO"])

    def test_no_books_no_alerts(self):
        self.assertEqual(analytics.warnings([], SETTINGS, date(2026, 3, 20)), [])

    def test_warnings_sorted_before_info(self):
        alerts = analytics.warnings(
            [book(1, "Huge", 1500, "2026-03-02"), book(2, "B", 300, "2026-03-03")], SETTINGS, date(2026, 3, 20)
        )
        levels = [a.level for a in alerts]
        self.assertEqual(levels, sorted(levels, key=lambda x: x != "WARN"))


if __name__ == "__main__":
    unittest.main()
