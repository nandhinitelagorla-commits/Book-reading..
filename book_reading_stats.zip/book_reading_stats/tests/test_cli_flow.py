"""End-to-end: drive the real menu with scripted keyboard input."""

import contextlib
import io
import tempfile
import unittest
from datetime import date
from pathlib import Path
from unittest import mock

from brs.cli import SAMPLE_CSV, App

TODAY = date(2026, 11, 23)


def run_session(data_dir, export_dir, lines):
    """Run the menu with `lines` as keyboard input; return everything printed."""
    app = App(data_dir=data_dir, export_dir=export_dir, today=TODAY)
    out = io.StringIO()
    queue = iter(lines)

    def fake_input(_prompt=""):
        try:
            return next(queue)
        except StopIteration:
            raise EOFError from None  # what a closed stdin does

    with mock.patch("builtins.input", fake_input), contextlib.redirect_stdout(out):
        app.run()
    return app, out.getvalue()


class CliFlow(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        root = Path(self._tmp.name)
        self.data, self.exports = root / "data", root / "exports"

    def tearDown(self):
        self._tmp.cleanup()

    def test_validation_loops_then_persists_across_restart(self):
        app, out = run_session(self.data, self.exports, [
            "1",
            "",                      # blank title   -> rejected
            "Dune",
            "Frank Herbert",
            "sci-fi",
            "abc", "-5", "99999",    # bad pages     -> rejected x3
            "688",
            "2099-01-01", "bad",     # bad dates     -> rejected x2
            "2026-11-01",
            "9", "0",                # bad ratings   -> rejected x2
            "5",
            "0",
        ])
        self.assertEqual(out.count("[x]"), 8)
        self.assertEqual(len(app.books), 1)
        self.assertEqual(app.books[0].genre, "Sci-Fi")

        # "restart": a brand-new App on the same folder sees the saved book
        app2, out2 = run_session(self.data, self.exports, ["2", "0"])
        self.assertEqual([b.title for b in app2.books], ["Dune"])
        self.assertIn("Dune", out2)
        self.assertIn("Loaded 1 book(s)", out2)

    def test_cancel_changes_nothing(self):
        app, out = run_session(self.data, self.exports, ["1", "Some Title", "/cancel", "0"])
        self.assertEqual(app.books, [])
        self.assertIn("Cancelled", out)

    def test_bad_menu_choice_does_not_crash(self):
        _, out = run_session(self.data, self.exports, ["", "abc", "99", "-1", "0"])
        self.assertEqual(out.count("Please enter a number"), 4)

    def test_import_sample_then_analyse_and_export(self):
        app, out = run_session(self.data, self.exports, [
            "10", str(SAMPLE_CSV),   # import sample
            "6",                     # summary
            "7",                     # monthly
            "11",                    # alerts
            "3", "weir", "", "", "", # search keyword
            "9",                     # export
            "0",
        ])
        self.assertEqual(len(app.books), 41)
        self.assertIn("Rows read: 41 | imported: 41", out)
        self.assertIn("KEY METRICS", out)
        self.assertIn("Total pages", out)
        self.assertIn("2 book(s)", out)  # The Martian + Project Hail Mary
        reports = list(self.exports.glob("report_*"))
        self.assertEqual(len(reports), 1)
        names = {p.name for p in reports[0].iterdir()}
        self.assertTrue({"report.md", "audit_log.txt", "books.csv", "monthly_summary.csv"} <= names)

    def test_edit_and_delete(self):
        app, _ = run_session(self.data, self.exports, ["10", str(SAMPLE_CSV), "0"])
        first_id = app.books[0].id
        app, out = run_session(self.data, self.exports, [
            "4", "9999", str(first_id),          # unknown id, then real id
            "", "", "", "321", "", "2",          # keep title/author/genre, new pages, keep date, rating 2
            "5", str(first_id), "n",             # decline delete
            "5", str(first_id), "y",             # confirm delete
            "0",
        ])
        self.assertIn("No book with ID 9999", out)
        self.assertEqual(len(app.books), 40)
        self.assertNotIn(first_id, [b.id for b in app.books])

    def test_pagination_and_eof_safety(self):
        # 41 books => 5 pages of 10; stop after the first page
        app, out = run_session(self.data, self.exports, ["10", str(SAMPLE_CSV), "2", "q", "0"])
        self.assertIn("Hooked", out)                # newest book is on page 1
        self.assertIn("The Power of Now", out)      # 10th row, still page 1
        self.assertNotIn("Project Hail Mary", out)  # 11th row, page 2 was never shown
        # input closing mid-prompt surfaces as EOFError for main() to handle
        with self.assertRaises(EOFError):
            run_session(self.data, self.exports, ["1", "Title only"])

    def test_settings_change_affects_status(self):
        app, out = run_session(self.data, self.exports, ["10", str(SAMPLE_CSV), "12", "50", "abc", "100000", "7", "0"])
        self.assertEqual(app.settings, {"monthly_goal_books": 50, "monthly_goal_pages": 100000})
        self.assertIn("BEHIND", out)

    def test_corrupt_store_recovers_on_startup(self):
        self.data.mkdir(parents=True)
        (self.data / "books.json").write_text("<<<garbage", encoding="utf-8")
        app, out = run_session(self.data, self.exports, ["0"])
        self.assertEqual(app.books, [])
        self.assertIn("corrupted", out)


if __name__ == "__main__":
    unittest.main()
