import json
import tempfile
import unittest
from datetime import date
from pathlib import Path

from brs.models import Book
from brs.storage import Storage, StorageError, import_csv, merge_books, write_error_log

TODAY = date(2026, 11, 23)
SAMPLES = Path(__file__).resolve().parent.parent / "sample_data"


def make_book(**kw):
    base = dict(title="T", author="A", genre="Fiction", pages=100, date_finished="2026-01-01", rating=4, id=1)
    base.update(kw)
    return Book(**base)


class JsonStore(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self._tmp.name) / "data"
        self.store = Storage(self.dir, today=TODAY)

    def tearDown(self):
        self._tmp.cleanup()

    def test_missing_file_creates_clean_template(self):
        self.assertEqual(self.store.load_books(), [])
        data = json.loads((self.dir / "books.json").read_text())
        self.assertEqual(data["books"], [])

    def test_round_trip(self):
        self.store.save_books([make_book(), make_book(id=2, title="Ünïcode – 本")])
        loaded = Storage(self.dir, today=TODAY).load_books()
        self.assertEqual([b.title for b in loaded], ["T", "Ünïcode – 本"])
        self.assertEqual(loaded[1].id, 2)

    def test_corrupt_json_is_quarantined(self):
        self.dir.mkdir(parents=True)
        (self.dir / "books.json").write_text("{ not json", encoding="utf-8")
        self.assertEqual(self.store.load_books(), [])
        self.assertTrue(list(self.dir.glob("books.corrupt-*.json")))
        self.assertTrue(self.store.notices)
        self.assertEqual(json.loads((self.dir / "books.json").read_text())["books"], [])

    def test_wrong_shape_is_quarantined(self):
        self.dir.mkdir(parents=True)
        (self.dir / "books.json").write_text('{"books": "nope"}', encoding="utf-8")
        self.assertEqual(self.store.load_books(), [])
        self.assertTrue(list(self.dir.glob("books.corrupt-*.json")))

    def test_invalid_records_skipped_and_backed_up(self):
        self.dir.mkdir(parents=True)
        good = make_book().to_dict()
        bad = dict(good, id=2, pages=-4)
        (self.dir / "books.json").write_text(json.dumps({"books": [good, bad, "junk"]}), encoding="utf-8")
        loaded = self.store.load_books()
        self.assertEqual(len(loaded), 1)
        self.assertTrue(list(self.dir.glob("books.skipped-*.json")))

    def test_missing_or_duplicate_ids_repaired(self):
        self.dir.mkdir(parents=True)
        a = make_book().to_dict()
        b = dict(a, title="B")
        c = {k: v for k, v in a.items() if k != "id"} | {"title": "C"}
        (self.dir / "books.json").write_text(json.dumps([a, b, c]), encoding="utf-8")
        ids = [bk.id for bk in self.store.load_books()]
        self.assertEqual(len(set(ids)), 3)

    def test_settings_defaults_and_invalid_values(self):
        self.assertEqual(self.store.load_settings()["monthly_goal_books"], 2)
        (self.dir / "settings.json").write_text('{"monthly_goal_books": 0, "monthly_goal_pages": 700}')
        s = self.store.load_settings()
        self.assertEqual(s["monthly_goal_books"], 2)
        self.assertEqual(s["monthly_goal_pages"], 700)

    def test_no_temp_files_left_behind(self):
        self.store.save_books([make_book()])
        self.assertFalse(list(self.dir.glob("*.tmp")))


class CsvImport(unittest.TestCase):
    def test_sample_dataset_is_fully_valid(self):
        result = import_csv(SAMPLES / "sample_books.csv", today=TODAY)
        self.assertEqual(result.total_rows, 41)
        self.assertEqual(len(result.valid), 41)
        self.assertEqual(result.errors, [])

    def test_sample_json_matches_csv(self):
        data = json.loads((SAMPLES / "sample_books.json").read_text(encoding="utf-8"))
        self.assertEqual(len(data["books"]), 41)

    def test_bad_import_reports_every_row(self):
        existing = import_csv(SAMPLES / "sample_books.csv", today=TODAY).valid
        result = import_csv(SAMPLES / "sample_bad_import.csv", existing=existing, today=TODAY)
        self.assertEqual(result.total_rows, 14)
        self.assertEqual(len(result.valid), 3)  # Valid Book One / Two / Three
        self.assertEqual(len(result.duplicates), 1)  # "Dune" already in the store
        self.assertEqual(len(result.errors), 10)
        lines = [e.line for e in result.errors]
        self.assertEqual(lines, sorted(lines))

    def test_missing_columns_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "x.csv"
            p.write_text("title,author\nA,B\n", encoding="utf-8")
            with self.assertRaises(StorageError):
                import_csv(p, today=TODAY)

    def test_empty_and_missing_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "empty.csv"
            p.write_text("", encoding="utf-8")
            with self.assertRaises(StorageError):
                import_csv(p, today=TODAY)
            with self.assertRaises(StorageError):
                import_csv(Path(tmp) / "nope.csv", today=TODAY)

    def test_non_utf8_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "latin.csv"
            p.write_bytes("title,author,genre,pages,date_finished,rating\nCaf\xe9,A,Fiction,10,2026-01-01,3\n".encode("latin-1"))
            with self.assertRaises(StorageError):
                import_csv(p, today=TODAY)

    def test_error_log_written(self):
        result = import_csv(SAMPLES / "sample_bad_import.csv", today=TODAY)
        with tempfile.TemporaryDirectory() as tmp:
            log = write_error_log(result, tmp)
            text = log.read_text(encoding="utf-8")
            self.assertIn("REJECTED", text)
            self.assertIn("Line 3", text)

    def test_merge_assigns_unique_ids(self):
        merged = merge_books([make_book(id=5)], [make_book(id=0), make_book(id=0)])
        self.assertEqual([b.id for b in merged], [5, 6, 7])


if __name__ == "__main__":
    unittest.main()
