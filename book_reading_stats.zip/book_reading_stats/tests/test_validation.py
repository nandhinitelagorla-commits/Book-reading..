import unittest
from datetime import date

from brs import validation as v

TODAY = date(2026, 11, 23)


class PagesAndRating(unittest.TestCase):
    def test_valid_pages(self):
        self.assertEqual(v.validate_pages("300"), 300)
        self.assertEqual(v.validate_pages(" 1,200 "), 1200)
        self.assertEqual(v.validate_pages(1), 1)
        self.assertEqual(v.validate_pages(10_000), 10_000)
        self.assertEqual(v.validate_pages(250.0), 250)

    def test_invalid_pages(self):
        for bad in ["", "   ", None, "abc", "0", "-5", "10001", "3.5", "12 pages", True, 2.5,
                    "४२", "9" * 5000]:
            with self.subTest(bad=bad), self.assertRaises(v.ValidationError):
                v.validate_pages(bad)

    def test_rating_bounds(self):
        self.assertEqual(v.validate_rating("1"), 1)
        self.assertEqual(v.validate_rating("5"), 5)
        for bad in ["0", "6", "", "four", "4.5"]:
            with self.subTest(bad=bad), self.assertRaises(v.ValidationError):
                v.validate_rating(bad)


class Dates(unittest.TestCase):
    def test_formats_normalised(self):
        self.assertEqual(v.validate_date("2026-03-05", TODAY), "2026-03-05")
        self.assertEqual(v.validate_date("05/03/2026", TODAY), "2026-03-05")
        self.assertEqual(v.validate_date("05-03-2026", TODAY), "2026-03-05")

    def test_today_is_allowed_future_is_not(self):
        self.assertEqual(v.validate_date("2026-11-23", TODAY), "2026-11-23")
        with self.assertRaises(v.ValidationError):
            v.validate_date("2026-11-24", TODAY)

    def test_bad_dates(self):
        for bad in ["", None, "yesterday", "2026-02-30", "2026-13-01", "1899-12-31", "2026/03/05"]:
            with self.subTest(bad=bad), self.assertRaises(v.ValidationError):
                v.validate_date(bad, TODAY)

    def test_month(self):
        self.assertEqual(v.validate_month("2026-3"), "2026-03")
        for bad in ["2026-13", "26-03", "march", ""]:
            with self.subTest(bad=bad), self.assertRaises(v.ValidationError):
                v.validate_month(bad)


class Text(unittest.TestCase):
    def test_whitespace_collapsed(self):
        self.assertEqual(v.validate_title("  The   Hobbit\t"), "The Hobbit")

    def test_blank_long_and_control(self):
        with self.assertRaises(v.ValidationError):
            v.validate_title("   ")
        with self.assertRaises(v.ValidationError):
            v.validate_title("x" * 151)
        with self.assertRaises(v.ValidationError):
            v.validate_author("bad\x00name")

    def test_genre_normalisation(self):
        self.assertEqual(v.validate_genre("self-help"), "Self-Help")
        self.assertEqual(v.validate_genre("children's"), "Children's")
        self.assertEqual(v.validate_genre("SCIENCE fiction"), "Science Fiction")
        self.assertEqual(v.validate_genre("sci-fi/fantasy"), "Sci-Fi/Fantasy")

    def test_genre_rejects_digits_and_symbols(self):
        for bad in ["Fic7ion", "123", "<b>", "-Fiction", ""]:
            with self.subTest(bad=bad), self.assertRaises(v.ValidationError):
                v.validate_genre(bad)


class Records(unittest.TestCase):
    def test_collects_all_errors(self):
        clean, errors = v.validate_record(
            {"title": "", "author": "A", "genre": "Fiction", "pages": "x", "date_finished": "2099-01-01", "rating": "9"},
            TODAY,
        )
        self.assertIsNone(clean)
        self.assertEqual(len(errors), 4)

    def test_valid_record(self):
        clean, errors = v.validate_record(
            {"title": "T", "author": "A", "genre": "fiction", "pages": "10", "date_finished": "2026-01-01", "rating": "3"},
            TODAY,
        )
        self.assertEqual(errors, [])
        self.assertEqual(clean["genre"], "Fiction")
        self.assertEqual(clean["pages"], 10)

    def test_non_mapping(self):
        self.assertIsNone(v.validate_record(["a", "b"], TODAY)[0])


if __name__ == "__main__":
    unittest.main()
