# Book Reading Statistics

A menu-driven Python app to track **books read, pages, genres and monthly reading totals**.
Data is saved locally (JSON), survives restarts, and can be summarised, charted and exported.

Built for the DataSpark Challenge (Project #94). Python 3.10+, standard library only —
except **Matplotlib**, which is used for charts (the app still runs without it).

## Quick start

```bash
# 1. (recommended) create a virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 2. install the only dependency (needed for charts)
pip install -r requirements.txt

# 3. run it, loading the bundled 41-book sample dataset on first launch
python main.py --load-sample

# later runs
python main.py
```

Run the tests: `python -m unittest discover -s tests -t .`

## Menu

| # | Option | What it does |
|---|--------|--------------|
| 1 | Add a book | Guided prompts; every field validated, bad input re-prompts |
| 2 | View all books | Fixed-width table, newest first, 10 per page |
| 3 | Search / filter | Keyword (title/author/genre), exact genre, month, minimum rating |
| 4 | Edit a book | Enter keeps the current value |
| 5 | Delete a book | Asks for confirmation |
| 6 | Summary report | Totals, averages, top genre/author, ratings, trend, alerts |
| 7 | Monthly totals & goals | Books/pages per month with GOAL MET / PARTIAL / BEHIND |
| 8 | Generate charts | PNGs: monthly trend, genres, cumulative pages, ratings, dashboard |
| 9 | Export reports | One folder with `report.md`, `audit_log.txt`, `books.csv`, `monthly_summary.csv` + charts |
| 10 | Import legacy CSV | Row-by-row validation, duplicate detection, error log file |
| 11 | Alerts & warnings | Threshold flags (see below) |
| 12 | Settings | Monthly goals (books and pages) |

Type `/cancel` at any prompt to abort the current action without changing anything.

## Validation rules

| Field | Rule |
|-------|------|
| Title / Author | Required, ≤150 / ≤100 characters, no control characters, whitespace tidied |
| Genre | Letters, spaces and `& / ' -` only; auto-capitalised (`self-help` → `Self-Help`) |
| Pages | Whole number 1–10,000 (`1,200` is accepted) |
| Date finished | `YYYY-MM-DD` (also `DD/MM/YYYY`, `DD-MM-YYYY`); not in the future; 1900 or later |
| Rating | Whole number 1–5 |

## Alerts (threshold warnings)

- Unusually long (> 1,200 pages) or short (< 10 pages) entries
- Possible duplicates (same title + author)
- More than 3 books finished on a single day
- No book logged for more than 30 days
- Current month's reading goal not yet met (with what is still needed and days left)

## Data and robustness

- Live data: `data/books.json` (+ `data/settings.json`), created automatically on first run.
- Saves are atomic (temp file + rename), so a crash can't leave a half-written file.
- A corrupted or wrong-shaped file is renamed to `books.corrupt-<timestamp>.json` and a clean
  one is created. Individual invalid records are skipped and the original is backed up.
- Closing the terminal / pressing Ctrl+C exits cleanly; every change is saved immediately.
- Exports and import error logs go to `exports/`.

## Project layout

```
main.py                 entry point (argparse: --data-dir, --export-dir, --load-sample)
brs/
  models.py             Book dataclass
  validation.py         pure validators (used by prompts, file loading and CSV import)
  storage.py            JSON store, settings, CSV import + error log
  analytics.py          totals, monthly/genre stats, trend, search, alerts
  reports.py            console/text/Markdown rendering and multi-format export
  plotting.py           Matplotlib charts (optional dependency)
  tables.py             fixed-width and Markdown tables
  ui.py                 ANSI colours, banner, validated prompts
  cli.py                menu loop and handlers
sample_data/
  sample_books.csv / .json     41 realistic entries (boundary + edge cases)
  sample_bad_import.csv        14 rows with deliberate errors, to demo import validation
tests/                  56 unit + end-to-end tests (unittest)
```

## Suggested 5-minute demo

1. `python main.py --load-sample` — branded welcome screen and menu.
2. **1 · Add a book** — type a blank title, `abc` and `99999` for pages, a future date and rating `9`
   to show each being caught and re-prompted, then enter valid values.
3. **6 · Summary report** and **7 · Monthly totals** — formatted tables, trend, goal status.
4. **11 · Alerts** — flags for the 1-page, 1,276-page and 1,463-page entries.
5. **10 · Import** `sample_data/sample_bad_import.csv` — see the row-by-row rejection log.
6. **9 · Export** — open the generated `report.md` and the PNG dashboard in `exports/`.
7. Exit, relaunch with `python main.py` — all data is still there.

## Ideas for extending

Tkinter/Textual front end, JSON import, reading-time tracking, yearly goals, per-genre goals.
