"""Matplotlib charts. Matplotlib is optional: the rest of the app works without it."""

from __future__ import annotations

import math
from pathlib import Path

from . import analytics

ACCENT = "#2F6DB5"
ACCENT_2 = "#E07A1F"
GRID = "#D9D9D9"


class PlottingUnavailable(RuntimeError):
    """Matplotlib is not installed."""


def _pyplot():
    try:
        import matplotlib

        matplotlib.use("Agg")  # file output only; works on servers and without a display
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise PlottingUnavailable(
            "Matplotlib is not installed. Install it with:  pip install matplotlib"
        ) from exc
    return plt


def _style(ax):
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)


def _thin_xticks(ax, labels):
    if len(labels) > 18:
        step = math.ceil(len(labels) / 12)
        ax.set_xticks(range(0, len(labels), step))
        ax.set_xticklabels(labels[::step])
    ax.tick_params(axis="x", rotation=45)


def _draw_monthly(ax, books):
    from matplotlib.ticker import MaxNLocator

    rows = analytics.monthly_totals(books)
    labels = [r["month"] for r in rows]
    ax.bar(labels, [r["pages"] for r in rows], color=ACCENT, label="Pages")
    ax.set_ylabel("Pages read")
    ax.set_title("Monthly reading trend")
    _style(ax)
    ax2 = ax.twinx()
    ax2.plot(labels, [r["books"] for r in rows], color=ACCENT_2, marker="o", label="Books")
    ax2.set_ylabel("Books finished")
    ax2.yaxis.set_major_locator(MaxNLocator(integer=True))
    ax2.set_ylim(bottom=0)
    ax2.spines["top"].set_visible(False)
    _thin_xticks(ax, labels)
    handles = ax.get_legend_handles_labels()[0] + ax2.get_legend_handles_labels()[0]
    names = ax.get_legend_handles_labels()[1] + ax2.get_legend_handles_labels()[1]
    ax.legend(handles, names, loc="upper left", frameon=False)


def _draw_genres(ax, books):
    rows = analytics.genre_breakdown(books)[:10][::-1]  # biggest at the top
    names = [r["genre"] for r in rows]
    counts = [r["books"] for r in rows]
    bars = ax.barh(names, counts, color=ACCENT)
    ax.bar_label(bars, padding=3)
    ax.set_xlabel("Books")
    ax.set_title("Books by genre")
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.set_xlim(right=max(counts) * 1.15)


def _draw_cumulative(ax, books):
    ordered = sorted(books, key=lambda b: (b.date_finished, b.id))
    dates, total, running = [], [], 0
    for b in ordered:
        running += b.pages
        dates.append(b.finished_on)
        total.append(running)
    ax.plot(dates, total, color=ACCENT, linewidth=2)
    ax.fill_between(dates, total, color=ACCENT, alpha=0.12)
    ax.set_ylabel("Cumulative pages")
    ax.set_title("Pages read over time")
    _style(ax)
    ax.tick_params(axis="x", rotation=45)


def _draw_ratings(ax, books):
    dist = analytics.rating_distribution(books)
    bars = ax.bar([str(k) for k in dist], list(dist.values()), color=ACCENT)
    ax.bar_label(bars, padding=2)
    ax.set_xlabel("Rating (stars)")
    ax.set_ylabel("Books")
    ax.set_title("Rating distribution")
    _style(ax)
    from matplotlib.ticker import MaxNLocator

    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    ax.set_ylim(top=max(dist.values()) * 1.15 or 1)


CHARTS = {
    "monthly_trend.png": (_draw_monthly, (9, 5)),
    "genre_distribution.png": (_draw_genres, (8, 5)),
    "cumulative_pages.png": (_draw_cumulative, (9, 5)),
    "rating_distribution.png": (_draw_ratings, (6, 4.5)),
}


def generate_all(books, out_dir) -> list[Path]:
    """Write the individual charts plus a combined dashboard; return the file paths."""
    if not books:
        raise ValueError("There are no books to plot yet.")
    plt = _pyplot()
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for filename, (draw, size) in CHARTS.items():
        fig, ax = plt.subplots(figsize=size)
        draw(ax, books)
        fig.tight_layout()
        path = out_dir / filename
        fig.savefig(path, dpi=150)
        plt.close(fig)
        paths.append(path)

    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    for ax, (draw, _size) in zip(axes.flat, CHARTS.values()):
        draw(ax, books)
    fig.suptitle("Book Reading Statistics - dashboard", fontsize=15, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    dashboard = out_dir / "reading_dashboard.png"
    fig.savefig(dashboard, dpi=130)
    plt.close(fig)
    paths.append(dashboard)
    return paths
