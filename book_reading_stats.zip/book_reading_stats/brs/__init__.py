"""Book Reading Statistics - a small, dependency-light reading tracker."""

APP_NAME = "Book Reading Statistics"
__version__ = "1.0.0"
