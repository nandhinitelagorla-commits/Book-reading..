"""Plain-text and Markdown table helpers (no colours, so safe for files)."""

from __future__ import annotations


def truncate(text, width: int) -> str:
    text = str(text)
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3] + "..."


def format_table(headers, rows, widths, aligns=None, sep: str = " | ") -> str:
    """Fixed-width table. aligns: list of 'l'/'r' per column."""
    aligns = aligns or ["l"] * len(headers)

    def cell(value, width, align):
        value = truncate(value, width)
        return value.rjust(width) if align == "r" else value.ljust(width)

    lines = [
        sep.join(cell(h, w, a) for h, w, a in zip(headers, widths, aligns)),
        "-+-".join("-" * w for w in widths),
    ]
    for row in rows:
        lines.append(sep.join(cell(v, w, a) for v, w, a in zip(row, widths, aligns)))
    return "\n".join(lines)


def md_table(headers, rows, aligns=None) -> str:
    aligns = aligns or ["l"] * len(headers)

    def esc(value):
        return str(value).replace("|", "\\|").replace("\n", " ")

    head = "| " + " | ".join(esc(h) for h in headers) + " |"
    rule = "| " + " | ".join("---:" if a == "r" else "---" for a in aligns) + " |"
    body = ["| " + " | ".join(esc(v) for v in row) + " |" for row in rows]
    return "\n".join([head, rule, *body])
