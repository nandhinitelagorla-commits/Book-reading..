"""Business logic: totals, monthly/genre breakdowns, trends, search, alerts."""

from __future__ import annotations

import calendar
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date

LONG_BOOK_PAGES = 1200
SHORT_BOOK_PAGES = 10
MAX_BOOKS_PER_DAY = 3
INACTIVITY_DAYS = 30


@dataclass(frozen=True)
class Alert:
    level: str  # "WARN" or "INFO"
    message: str


# ------------------------------------------------------------------ monthly
def monthly_totals(books) -> list[dict]:
    """One row per calendar month between first and last entry (gaps = zeros)."""
    if not books:
        return []
    buckets = defaultdict(list)
    for book in books:
        buckets[book.month].append(book)
    first, last = min(buckets), max(buckets)
    year, month = map(int, first.split("-"))
    last_year, last_month = map(int, last.split("-"))
    rows = []
    while (year, month) <= (last_year, last_month):
        key = f"{year:04d}-{month:02d}"
        items = buckets.get(key, [])
        rows.append(
            {
                "month": key,
                "books": len(items),
                "pages": sum(b.pages for b in items),
                "avg_rating": round(sum(b.rating for b in items) / len(items), 2) if items else None,
            }
        )
        month += 1
        if month == 13:
            year, month = year + 1, 1
    return rows


def goal_status(row: dict, settings: dict) -> str:
    books_ok = row["books"] >= settings["monthly_goal_books"]
    pages_ok = row["pages"] >= settings["monthly_goal_pages"]
    if books_ok and pages_ok:
        return "GOAL MET"
    return "PARTIAL" if (books_ok or pages_ok) else "BEHIND"


# ---------------------------------------------------------------- breakdowns
def genre_breakdown(books) -> list[dict]:
    total = len(books)
    counts, pages = Counter(), Counter()
    for b in books:
        counts[b.genre] += 1
        pages[b.genre] += b.pages
    rows = [
        {"genre": g, "books": n, "pages": pages[g], "share": n / total * 100}
        for g, n in counts.items()
    ]
    return sorted(rows, key=lambda r: (-r["books"], -r["pages"], r["genre"]))


def author_breakdown(books, top: int = 5) -> list[dict]:
    counts, pages = Counter(), Counter()
    for b in books:
        counts[b.author] += 1
        pages[b.author] += b.pages
    rows = [{"author": a, "books": n, "pages": pages[a]} for a, n in counts.items()]
    rows.sort(key=lambda r: (-r["books"], -r["pages"], r["author"]))
    return rows[:top]


def rating_distribution(books) -> dict[int, int]:
    counts = Counter(b.rating for b in books)
    return {star: counts.get(star, 0) for star in range(1, 6)}


# ------------------------------------------------------------------- summary
def summary(books) -> dict:
    if not books:
        return {"total_books": 0}
    monthly = monthly_totals(books)
    total_pages = sum(b.pages for b in books)
    genres = genre_breakdown(books)
    authors = author_breakdown(books, top=1)
    best = max(monthly, key=lambda r: (r["pages"], r["month"]))
    dates = sorted(b.date_finished for b in books)
    return {
        "total_books": len(books),
        "total_pages": total_pages,
        "avg_pages": total_pages / len(books),
        "median_pages": statistics.median(b.pages for b in books),
        "avg_rating": statistics.fmean(b.rating for b in books),
        "longest": max(books, key=lambda b: (b.pages, b.title)),
        "shortest": min(books, key=lambda b: (b.pages, b.title)),
        "top_genre": genres[0],
        "top_author": authors[0],
        "first_date": dates[0],
        "last_date": dates[-1],
        "months_tracked": len(monthly),
        "avg_books_per_month": len(books) / len(monthly),
        "avg_pages_per_month": total_pages / len(monthly),
        "best_month": best,
    }


def trend(monthly: list[dict], today: date | None = None) -> dict | None:
    """Latest month vs the one before, plus a straight-line trend over all months."""
    if len(monthly) < 2:
        return None
    latest, previous = monthly[-1], monthly[-2]
    change = None
    if previous["pages"] > 0:
        change = round((latest["pages"] - previous["pages"]) / previous["pages"] * 100, 1)
    slope, direction = None, "flat"
    if len(monthly) >= 3:
        ys = [r["pages"] for r in monthly]
        slope = statistics.linear_regression(list(range(len(ys))), ys).slope
        mean = statistics.fmean(ys)
        if mean > 0:
            relative = slope / mean
            direction = "up" if relative > 0.03 else "down" if relative < -0.03 else "flat"
    elif change is not None:
        direction = "up" if change > 3 else "down" if change < -3 else "flat"
    in_progress = bool(today) and latest["month"] == today.strftime("%Y-%m")
    return {
        "latest": latest,
        "previous": previous,
        "change_pct": change,
        "slope": slope,
        "direction": direction,
        "in_progress": in_progress,
    }


# -------------------------------------------------------------------- search
def search(books, keyword=None, genre=None, min_rating=None, month=None, author=None):
    """Filter books. All supplied criteria must match (AND); text is case-insensitive."""
    results = []
    kw = keyword.casefold() if keyword else None
    for b in books:
        if kw and kw not in f"{b.title} {b.author} {b.genre}".casefold():
            continue
        if genre and genre.casefold() != b.genre.casefold():
            continue
        if author and author.casefold() not in b.author.casefold():
            continue
        if min_rating is not None and b.rating < min_rating:
            continue
        if month and b.month != month:
            continue
        results.append(b)
    return results


# -------------------------------------------------------------------- alerts
def entry_alerts(book) -> list[Alert]:
    alerts = []
    if book.pages > LONG_BOOK_PAGES:
        alerts.append(
            Alert("WARN", f"Unusually long entry (ID {book.id}): '{book.title}' has {book.pages:,} pages - please verify.")
        )
    if book.pages < SHORT_BOOK_PAGES:
        alerts.append(
            Alert("WARN", f"Unusually short entry (ID {book.id}): '{book.title}' has only {book.pages} page(s) - please verify.")
        )
    return alerts


def warnings(books, settings: dict, today: date | None = None) -> list[Alert]:
    today = today or date.today()
    alerts: list[Alert] = []
    for book in sorted(books, key=lambda b: b.id):
        alerts.extend(entry_alerts(book))

    groups = defaultdict(list)
    for book in books:
        groups[(book.title.casefold(), book.author.casefold())].append(book)
    for items in groups.values():
        if len(items) > 1:
            ids = ", ".join(str(b.id) for b in items)
            alerts.append(
                Alert("WARN", f"Possible duplicate: '{items[0].title}' by {items[0].author} is logged {len(items)} times (IDs {ids}).")
            )

    for day, count in sorted(Counter(b.date_finished for b in books).items()):
        if count > MAX_BOOKS_PER_DAY:
            alerts.append(Alert("WARN", f"{count} books finished on {day} - is that right?"))

    if books:
        last = max(b.finished_on for b in books)
        idle = (today - last).days
        if idle > INACTIVITY_DAYS:
            alerts.append(Alert("WARN", f"No book logged for {idle} days (last finished {last.isoformat()})."))

        key = today.strftime("%Y-%m")
        mine = [b for b in books if b.month == key]
        n_books, n_pages = len(mine), sum(b.pages for b in mine)
        goal_b, goal_p = settings["monthly_goal_books"], settings["monthly_goal_pages"]
        label = f"{calendar.month_name[today.month]} {today.year}"
        if n_books >= goal_b and n_pages >= goal_p:
            alerts.append(Alert("INFO", f"{label} goal met: {n_books} book(s), {n_pages:,} pages."))
        else:
            days_left = calendar.monthrange(today.year, today.month)[1] - today.day
            needs = []
            if n_books < goal_b:
                needs.append(f"{goal_b - n_books} more book(s)")
            if n_pages < goal_p:
                needs.append(f"{goal_p - n_pages:,} more pages")
            alerts.append(
                Alert("WARN", f"{label} goal not met yet: needs {' and '.join(needs)}, {days_left} day(s) left.")
            )
    return sorted(alerts, key=lambda a: a.level != "WARN")  # warnings first (stable)
