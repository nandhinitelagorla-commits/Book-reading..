"""Core data model."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date

# Column order used for CSV files and JSON records.
FIELDS = ("id", "title", "author", "genre", "pages", "date_finished", "rating")


@dataclass
class Book:
    title: str
    author: str
    genre: str
    pages: int
    date_finished: str  # ISO 8601 (YYYY-MM-DD)
    rating: int  # 1-5
    id: int = 0

    @property
    def finished_on(self) -> date:
        return date.fromisoformat(self.date_finished)

    @property
    def month(self) -> str:
        """Month bucket, e.g. '2026-03'."""
        return self.date_finished[:7]

    def to_dict(self) -> dict:
        data = asdict(self)
        return {key: data[key] for key in FIELDS}

    @classmethod
    def from_clean(cls, clean: dict, book_id: int = 0) -> "Book":
        """Build a Book from a dict that already passed validate_record()."""
        return cls(
            id=book_id,
            title=clean["title"],
            author=clean["author"],
            genre=clean["genre"],
            pages=clean["pages"],
            date_finished=clean["date_finished"],
            rating=clean["rating"],
        )
