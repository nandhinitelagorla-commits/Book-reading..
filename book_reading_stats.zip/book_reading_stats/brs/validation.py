"""Defensive input validation.

Every validator takes a raw value (usually a string typed by the user or read
from a file), returns a clean value, or raises ValidationError with a
human-readable message. Nothing here prints or reads input, so it is easy to
unit-test and reuse for both interactive prompts and bulk CSV import.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from datetime import date, datetime

MIN_PAGES, MAX_PAGES = 1, 10_000
MIN_RATING, MAX_RATING = 1, 5
MIN_YEAR = 1900
DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y")

_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")
_GENRE_WORD = re.compile(r"[^\W\d_]+(?:'[^\W\d_]+)?")


class ValidationError(ValueError):
    """Raised when a value does not satisfy the domain rules."""


def _clean_text(value, label: str, max_len: int) -> str:
    text = "" if value is None else str(value)
    text = " ".join(text.split())  # trim + collapse tabs/newlines/spaces
    if not text:
        raise ValidationError(f"{label} cannot be blank.")
    if _CONTROL_CHARS.search(text):
        raise ValidationError(f"{label} contains unprintable characters.")
    if len(text) > max_len:
        raise ValidationError(f"{label} is too long (max {max_len} characters).")
    return text


def validate_title(value) -> str:
    return _clean_text(value, "Title", 150)


def validate_author(value) -> str:
    return _clean_text(value, "Author", 100)


def validate_genre(value) -> str:
    text = _clean_text(value, "Genre", 40)
    if not text[0].isalpha() or not all(ch.isalpha() or ch in " &/'-" for ch in text):
        raise ValidationError(
            "Genre may only contain letters, spaces and & / ' - (no digits or symbols)."
        )
    # 'self-help' -> 'Self-Help', "children's" -> "Children's"
    return _GENRE_WORD.sub(lambda m: m.group(0).capitalize(), text)


def validate_int(value, label: str, lo: int, hi: int) -> int:
    """Whole number within [lo, hi]. Accepts '1,200' style thousands separators."""
    if value is None:
        value = ""
    if isinstance(value, bool):
        raise ValidationError(f"{label} must be a whole number.")
    if isinstance(value, int):
        number = value
    elif isinstance(value, float) and value.is_integer():
        number = int(value)
    else:
        text = str(value).strip().replace(",", "")
        if not text:
            raise ValidationError(f"{label} cannot be blank.")
        if not (text.isascii() and text.isdigit()):
            raise ValidationError(
                f"{label} must be a whole number (digits only), got {text[:20]!r}."
            )
        if len(text) > 9:  # also avoids Python's huge-int conversion limit
            raise ValidationError(f"{label} must be between {lo:,} and {hi:,}.")
        number = int(text)
    if not lo <= number <= hi:
        raise ValidationError(f"{label} must be between {lo:,} and {hi:,}.")
    return number


def validate_pages(value) -> int:
    return validate_int(value, "Pages", MIN_PAGES, MAX_PAGES)


def validate_rating(value) -> int:
    return validate_int(value, "Rating", MIN_RATING, MAX_RATING)


def validate_date(value, today: date | None = None) -> str:
    """Return an ISO date string. Rejects future dates and dates before 1900."""
    today = today or date.today()
    text = "" if value is None else str(value).strip()
    if not text:
        raise ValidationError("Date cannot be blank.")
    parsed = None
    for fmt in DATE_FORMATS:
        try:
            parsed = datetime.strptime(text, fmt).date()
            break
        except ValueError:
            continue
    if parsed is None:
        raise ValidationError(
            f"Date {text[:20]!r} is not valid. Use YYYY-MM-DD (e.g. 2026-03-15)."
        )
    if parsed.year < MIN_YEAR:
        raise ValidationError(f"Date must be {MIN_YEAR} or later.")
    if parsed > today:
        raise ValidationError(f"Date {parsed.isoformat()} is in the future.")
    return parsed.isoformat()


def validate_month(value) -> str:
    """'2026-3' or '2026-03' -> '2026-03'."""
    text = "" if value is None else str(value).strip()
    match = re.fullmatch(r"(\d{4})-(\d{1,2})", text)
    if not match or not 1 <= int(match[2]) <= 12 or int(match[1]) < MIN_YEAR:
        raise ValidationError("Month must look like YYYY-MM (e.g. 2026-03).")
    return f"{int(match[1]):04d}-{int(match[2]):02d}"


def validate_record(raw, today: date | None = None):
    """Validate a whole record (dict-like).

    Returns (clean_dict, []) on success or (None, [error messages]) on failure.
    All field errors are collected so users see everything wrong at once.
    """
    if not isinstance(raw, Mapping):
        return None, ["Record is not an object/row of named fields."]
    checks = (
        ("title", validate_title),
        ("author", validate_author),
        ("genre", validate_genre),
        ("pages", validate_pages),
        ("date_finished", lambda v: validate_date(v, today)),
        ("rating", validate_rating),
    )
    clean, errors = {}, []
    for key, check in checks:
        try:
            clean[key] = check(raw.get(key))
        except ValidationError as exc:
            errors.append(str(exc))
    return (None if errors else clean), errors
