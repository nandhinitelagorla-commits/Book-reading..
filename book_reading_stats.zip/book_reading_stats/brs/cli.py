"""Menu-driven terminal interface."""

from __future__ import annotations

from datetime import date
from pathlib import Path

from . import APP_NAME, __version__, analytics, plotting, reports, ui
from . import validation as v
from .models import Book
from .storage import (
    Storage,
    StorageError,
    import_csv,
    merge_books,
    next_id,
    write_error_log,
)
from .tables import format_table

PAGE_SIZE = 10
SAMPLE_CSV = Path(__file__).resolve().parent.parent / "sample_data" / "sample_books.csv"

MENU_LEFT = [
    ("1", "Add a book"),
    ("2", "View all books"),
    ("3", "Search / filter"),
    ("4", "Edit a book"),
    ("5", "Delete a book"),
    ("6", "Summary report"),
]
MENU_RIGHT = [
    ("7", "Monthly totals & goals"),
    ("8", "Generate charts (PNG)"),
    ("9", "Export reports"),
    ("10", "Import legacy CSV"),
    ("11", "Alerts & warnings"),
    ("12", "Settings (monthly goals)"),
]


class App:
    def __init__(self, data_dir="data", export_dir="exports", today: date | None = None):
        self._today_override = today
        self.export_dir = Path(export_dir)
        self.storage = Storage(data_dir, today=today)
        self.books = self.storage.load_books()
        self.settings = self.storage.load_settings()
        self.startup_notices = list(self.storage.notices)
        self.actions = {
            "1": self.add_book,
            "2": self.view_all,
            "3": self.search_books,
            "4": self.edit_book,
            "5": self.delete_book,
            "6": self.show_summary,
            "7": self.show_monthly,
            "8": self.make_charts,
            "9": self.export_reports,
            "10": self.import_flow,
            "11": self.show_alerts,
            "12": self.edit_settings,
        }

    # --------------------------------------------------------------- basics
    def _today(self) -> date:
        return self._today_override or date.today()

    def _save(self) -> None:
        self.storage.save_books(self.books)

    def _book_by_id(self, raw) -> Book:
        number = v.validate_int(raw, "Book ID", 1, 10**9)
        for book in self.books:
            if book.id == number:
                return book
        raise v.ValidationError(f"No book with ID {number}. Use option 2 or 3 to look up IDs.")

    def _has_duplicate(self, title: str, author: str, ignore_id: int | None = None) -> bool:
        key = (title.casefold(), author.casefold())
        return any(
            (b.title.casefold(), b.author.casefold()) == key and b.id != ignore_id
            for b in self.books
        )

    def _need_books(self) -> bool:
        if self.books:
            return True
        ui.info("No books logged yet. Add one with option 1 or import a CSV with option 10.")
        return False

    # ------------------------------------------------------------ main loop
    def run(self) -> None:
        ui.banner(__version__)
        for notice in self.startup_notices[:6]:
            ui.warn(notice)
        self._startup_status()
        while True:
            self._print_menu()
            choice = input("Choose an option: ").strip()
            if choice == "0":
                ui.info("Your data is saved. Goodbye!")
                return
            action = self.actions.get(choice)
            if action is None:
                ui.error("Please enter a number from the menu (0-12).")
                continue
            try:
                action()
            except ui.UserCancelled:
                ui.info("Cancelled - nothing was changed.")
            except EOFError:
                raise
            except StorageError as exc:
                ui.error(str(exc))
            except OSError as exc:
                ui.error(f"File problem: {exc}")
            except Exception as exc:  # keep the session alive for the demo
                ui.error(f"Unexpected problem ({type(exc).__name__}): {exc}")

    def _startup_status(self) -> None:
        if not self.books:
            ui.info("No data yet. Tip: choose option 10 to import the bundled sample dataset.")
            return
        alerts = [a for a in analytics.warnings(self.books, self.settings, self._today()) if a.level == "WARN"]
        msg = f"Loaded {len(self.books)} book(s)."
        if alerts:
            msg += f" {len(alerts)} warning(s) - choose 11 to review."
        ui.info(msg)

    def _print_menu(self) -> None:
        ui.heading("MAIN MENU")
        for (lk, lv), (rk, rv) in zip(MENU_LEFT, MENU_RIGHT):
            print(f" {lk:>2}) {lv:<22}  {rk:>2}) {rv}")
        print("  0) Exit")

    # ------------------------------------------------------------ add/edit
    def add_book(self) -> None:
        ui.heading("Add a book   (type /cancel at any prompt to abort)")
        today = self._today()
        title = ui.ask("Title", v.validate_title)
        author = ui.ask("Author", v.validate_author)
        genre = ui.ask("Genre (e.g. Fiction, Science, Memoir)", v.validate_genre)
        pages = ui.ask("Pages (1-10,000)", v.validate_pages)
        finished = ui.ask(
            "Date finished (YYYY-MM-DD)", lambda s: v.validate_date(s, today), default=today.isoformat()
        )
        rating = ui.ask("Rating (1-5)", v.validate_rating)
        if self._has_duplicate(title, author) and not ui.confirm(
            "This title and author are already logged. Add anyway?"
        ):
            ui.info("Not added.")
            return
        book = Book(title=title, author=author, genre=genre, pages=pages,
                    date_finished=finished, rating=rating, id=next_id(self.books))
        self.books.append(book)
        self._save()
        ui.success(f"Saved '{book.title}' as ID {book.id}.")
        for alert in analytics.entry_alerts(book):
            ui.warn(alert.message)

    def edit_book(self) -> None:
        if not self._need_books():
            return
        ui.heading("Edit a book   (press Enter to keep the current value)")
        book = ui.ask("Book ID to edit", self._book_by_id)
        today = self._today()
        title = ui.ask("Title", v.validate_title, default=book.title)
        author = ui.ask("Author", v.validate_author, default=book.author)
        genre = ui.ask("Genre", v.validate_genre, default=book.genre)
        pages = ui.ask("Pages", v.validate_pages, default=book.pages)
        finished = ui.ask("Date finished", lambda s: v.validate_date(s, today), default=book.date_finished)
        rating = ui.ask("Rating", v.validate_rating, default=book.rating)
        if self._has_duplicate(title, author, ignore_id=book.id) and not ui.confirm(
            "Another entry has this title and author. Save anyway?"
        ):
            ui.info("Not saved.")
            return
        book.title, book.author, book.genre = title, author, genre
        book.pages, book.date_finished, book.rating = pages, finished, rating
        self._save()
        ui.success(f"Updated ID {book.id}.")
        for alert in analytics.entry_alerts(book):
            ui.warn(alert.message)

    def delete_book(self) -> None:
        if not self._need_books():
            return
        ui.heading("Delete a book")
        book = ui.ask("Book ID to delete", self._book_by_id)
        if ui.confirm(f"Delete '{book.title}' by {book.author}? This cannot be undone."):
            self.books.remove(book)
            self._save()
            ui.success("Deleted.")
        else:
            ui.info("Kept.")

    # -------------------------------------------------------- view / search
    def _book_table(self, books) -> str:
        fixed = [3, 16, 12, 6, 10, 4]
        title_w = max(14, min(40, ui.term_width() - sum(fixed) - 3 * 6))
        rows = [
            (b.id, b.title, b.author, b.genre, f"{b.pages:,}", b.date_finished, f"{b.rating}/5")
            for b in books
        ]
        return format_table(
            ["ID", "Title", "Author", "Genre", "Pages", "Finished", "Rate"],
            rows,
            [3, title_w, 16, 12, 6, 10, 4],
            ["r", "l", "l", "l", "r", "l", "r"],
        )

    def _show_paged(self, books) -> None:
        ordered = sorted(books, key=lambda b: (b.date_finished, b.id), reverse=True)
        total_pages = sum(b.pages for b in ordered)
        print(f"{len(ordered)} book(s), {total_pages:,} pages (newest first)")
        for start in range(0, len(ordered), PAGE_SIZE):
            print(self._book_table(ordered[start : start + PAGE_SIZE]))
            shown = start + PAGE_SIZE
            if shown < len(ordered):
                answer = input(f"-- {shown} of {len(ordered)} shown. Enter = next page, q = stop: ").strip().lower()
                if answer in ("q", "quit", "stop"):
                    break

    def view_all(self) -> None:
        if not self._need_books():
            return
        ui.heading("All books")
        self._show_paged(self.books)

    def search_books(self) -> None:
        if not self._need_books():
            return
        ui.heading("Search / filter   (leave a prompt blank to skip it)")
        keyword = ui.ask("Keyword (title, author or genre)", ui.optional(v.validate_title), default="")
        genre = ui.ask("Exact genre", ui.optional(v.validate_genre), default="")
        month = ui.ask("Month (YYYY-MM)", ui.optional(v.validate_month), default="")
        min_rating = ui.ask("Minimum rating (1-5)", ui.optional(v.validate_rating), default="")
        results = analytics.search(self.books, keyword=keyword, genre=genre, min_rating=min_rating, month=month)
        if not results:
            ui.info("No books match those filters.")
            return
        self._show_paged(results)

    # ------------------------------------------------------------- analytics
    def show_summary(self) -> None:
        if not self._need_books():
            return
        ui.heading("Summary report")
        print(reports.summary_text(self.books, self.settings, self._today()))

    def show_monthly(self) -> None:
        if not self._need_books():
            return
        ui.heading("Monthly totals & goal status")
        print(reports.monthly_text(analytics.monthly_totals(self.books), self.settings))

    def show_alerts(self) -> None:
        ui.heading("Alerts & warnings")
        alerts = analytics.warnings(self.books, self.settings, self._today())
        if not alerts:
            ui.success("No alerts - everything looks normal.")
        for alert in alerts:
            (ui.warn if alert.level == "WARN" else ui.info)(alert.message)

    # --------------------------------------------------------- charts/export
    def make_charts(self) -> None:
        if not self._need_books():
            return
        ui.heading("Generate charts")
        try:
            paths = plotting.generate_all(self.books, self.export_dir / "charts")
        except plotting.PlottingUnavailable as exc:
            ui.error(str(exc))
            return
        ui.success(f"Saved {len(paths)} chart(s) to {paths[0].parent}")
        for path in paths:
            print(f"  - {path.name}")

    def export_reports(self) -> None:
        if not self._need_books():
            return
        ui.heading("Export reports (Markdown, text audit log, CSV, charts)")
        folder, files, chart_note = reports.export_all(self.books, self.settings, self.export_dir, self._today())
        ui.success(f"Report written to {folder}")
        for path in files:
            print(f"  - {path.name}")
        if chart_note:
            ui.warn(f"Charts skipped: {chart_note}")

    # ----------------------------------------------------------- import/settings
    def import_file(self, path) -> tuple:
        """Validate + merge a CSV. Returns (result, log_path or None). Saves if anything was added."""
        result = import_csv(path, self.books, self._today())
        log_path = None
        if result.errors or result.duplicates:
            log_path = write_error_log(result, self.export_dir)
        if result.valid:
            self.books = merge_books(self.books, result.valid)
            self._save()
        return result, log_path

    @staticmethod
    def _csv_path(raw: str) -> Path:
        text = raw.strip().strip('"').strip("'")  # drag-and-drop adds quotes
        path = Path(text).expanduser()
        if not path.is_file():
            raise v.ValidationError(f"File not found: {text}")
        if path.suffix.lower() != ".csv":
            raise v.ValidationError("Please choose a .csv file.")
        return path

    def import_flow(self) -> None:
        ui.heading("Import legacy CSV")
        print("Required columns: title, author, genre, pages, date_finished, rating")
        default = str(SAMPLE_CSV) if SAMPLE_CSV.is_file() else None
        path = ui.ask("CSV file path", self._csv_path, default=default)
        result, log_path = self.import_file(path)
        print(
            f"Rows read: {result.total_rows} | imported: {len(result.valid)} | "
            f"duplicates skipped: {len(result.duplicates)} | rejected: {len(result.errors)}"
        )
        for err in result.errors[:5]:
            ui.warn(f"Line {err.line}: {err.message}")
        if len(result.errors) > 5:
            print(f"  ...and {len(result.errors) - 5} more (see the log)")
        if result.valid:
            ui.success(f"Added {len(result.valid)} book(s).")
        if log_path:
            ui.info(f"Row-by-row log: {log_path}")

    def edit_settings(self) -> None:
        ui.heading("Monthly reading goals   (Enter keeps the current value)")
        books_goal = ui.ask(
            "Books per month (1-100)",
            lambda s: v.validate_int(s, "Books goal", 1, 100),
            default=self.settings["monthly_goal_books"],
        )
        pages_goal = ui.ask(
            "Pages per month (1-100,000)",
            lambda s: v.validate_int(s, "Pages goal", 1, 100_000),
            default=self.settings["monthly_goal_pages"],
        )
        self.settings = {"monthly_goal_books": books_goal, "monthly_goal_pages": pages_goal}
        self.storage.save_settings(self.settings)
        ui.success("Goals saved.")
