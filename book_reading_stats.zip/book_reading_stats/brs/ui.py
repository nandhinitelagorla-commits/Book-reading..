"""Terminal helpers: colours, banner, safe prompts."""

from __future__ import annotations

import os
import shutil
import sys

from .validation import ValidationError

_CODES = {"bold": "1", "dim": "2", "red": "31", "green": "32", "yellow": "33", "cyan": "36"}


class UserCancelled(Exception):
    """User typed /cancel at a prompt."""


def enable_ansi() -> None:
    """Switch on ANSI colour handling in the Windows console (no-op elsewhere)."""
    if os.name == "nt":
        os.system("")
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def paint(text: str, style: str) -> str:
    if sys.stdout.isatty() and "NO_COLOR" not in os.environ:
        return f"\033[{_CODES[style]}m{text}\033[0m"
    return text


def term_width() -> int:
    return shutil.get_terminal_size((100, 24)).columns


def success(msg: str) -> None:
    print(paint(f"[OK] {msg}", "green"))


def info(msg: str) -> None:
    print(paint(msg, "cyan"))


def warn(msg: str) -> None:
    print(paint(f"[!] {msg}", "yellow"))


def error(msg: str) -> None:
    print(paint(f"[x] {msg}", "red"))


def heading(msg: str) -> None:
    print()
    print(paint(msg, "bold"))
    print(paint("-" * min(len(msg), 78), "dim"))


def banner(version: str) -> None:
    lines = [
        "BOOK READING STATISTICS",
        f"v{version}",
        "Track books, pages, genres & monthly reading totals",
    ]
    inner = max(len(x) for x in lines) + 6
    print(paint("+" + "=" * inner + "+", "cyan"))
    for i, line in enumerate(lines):
        print(paint("|" + line.center(inner) + "|", "bold" if i == 0 else "cyan"))
    print(paint("+" + "=" * inner + "+", "cyan"))


def ask(prompt: str, validator, default=None):
    """Prompt until `validator(text)` succeeds. Blank input uses `default` if given.

    Type /cancel to abort. EOFError (closed input) is deliberately not caught so
    scripted runs end cleanly instead of looping forever.
    """
    suffix = f" [{default}]" if default not in (None, "") else ""
    while True:
        raw = input(f"{prompt}{suffix}: ").strip()
        if raw.lower() == "/cancel":
            raise UserCancelled
        if raw == "" and default is not None:
            raw = str(default)
        try:
            return validator(raw)
        except ValidationError as exc:
            error(str(exc))


def optional(validator):
    """Wrap a validator so blank input means 'no value' (None)."""

    def wrapped(text):
        return None if not str(text).strip() else validator(text)

    return wrapped


def confirm(prompt: str) -> bool:
    while True:
        answer = input(f"{prompt} [y/n]: ").strip().lower()
        if answer in ("y", "yes"):
            return True
        if answer in ("n", "no", "/cancel"):
            return False
        error("Please answer y or n.")
