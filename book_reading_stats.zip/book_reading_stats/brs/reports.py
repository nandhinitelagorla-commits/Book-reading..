"""Summary rendering (console / text) and multi-format export."""

from __future__ import annotations

import csv
from datetime import date, datetime
from pathlib import Path

from . import analytics, plotting
from .models import FIELDS
from .tables import format_table, md_table

STATUS_LABEL = {"GOAL MET": "GOAL MET", "PARTIAL": "PARTIAL", "BEHIND": "BEHIND"}


def _section(title: str, body: str) -> str:
    return f"{title}\n{'=' * len(title)}\n{body}"


# ------------------------------------------------------------ data builders
def metrics_rows(s: dict) -> list[tuple[str, str]]:
    best = s["best_month"]
    return [
        ("Books read", f"{s['total_books']:,}"),
        ("Total pages", f"{s['total_pages']:,}"),
        ("Average pages per book", f"{s['avg_pages']:,.0f}"),
        ("Median pages per book", f"{s['median_pages']:,.0f}"),
        ("Average rating", f"{s['avg_rating']:.2f} / 5"),
        ("Longest book", f"{s['longest'].title} ({s['longest'].pages:,} pp)"),
        ("Shortest book", f"{s['shortest'].title} ({s['shortest'].pages:,} pp)"),
        ("Top genre", f"{s['top_genre']['genre']} ({s['top_genre']['books']} books)"),
        ("Top author", f"{s['top_author']['author']} ({s['top_author']['books']} books)"),
        ("Tracking period", f"{s['first_date']} to {s['last_date']} ({s['months_tracked']} months)"),
        ("Average books per month", f"{s['avg_books_per_month']:.1f}"),
        ("Average pages per month", f"{s['avg_pages_per_month']:,.0f}"),
        ("Best month", f"{best['month']} ({best['pages']:,} pages, {best['books']} books)"),
    ]


def _monthly_rows(monthly, settings):
    rows = []
    for r in monthly:
        rating = f"{r['avg_rating']:.1f}" if r["avg_rating"] is not None else "-"
        rows.append((r["month"], r["books"], f"{r['pages']:,}", rating, analytics.goal_status(r, settings)))
    return rows


MONTH_HEADERS = ["Month", "Books", "Pages", "Avg rating", "Goal status"]
MONTH_ALIGNS = ["l", "r", "r", "r", "l"]


def trend_sentence(t) -> str:
    if t is None:
        return "Not enough months of data yet (need at least 2)."
    latest, prev = t["latest"], t["previous"]
    note = " (month still in progress)" if t["in_progress"] else ""
    if t["change_pct"] is None:
        change = f"{latest['pages']:,} pages vs 0 in {prev['month']}"
    else:
        change = f"{t['change_pct']:+.1f}% pages vs {prev['month']}"
    overall = {"up": "increasing", "down": "decreasing", "flat": "roughly flat"}[t["direction"]]
    return f"{latest['month']}{note}: {change}. Overall monthly pace is {overall}."


# ---------------------------------------------------------------- text parts
def metrics_text(s) -> str:
    rows = metrics_rows(s)
    width = max(len(k) for k, _ in rows)
    return "\n".join(f"{k.ljust(width)} : {v}" for k, v in rows)


def monthly_text(monthly, settings, limit: int | None = None) -> str:
    shown = monthly[-limit:] if limit else monthly
    table = format_table(MONTH_HEADERS, _monthly_rows(shown, settings), [7, 5, 8, 10, 11], MONTH_ALIGNS)
    if limit and len(monthly) > limit:
        table += f"\n(showing the latest {limit} of {len(monthly)} months)"
    goals = f"Goal: {settings['monthly_goal_books']} book(s) and {settings['monthly_goal_pages']:,} pages per month."
    return f"{table}\n{goals}"


def genre_text(genres, limit: int = 10) -> str:
    rows = [(g["genre"], g["books"], f"{g['pages']:,}", f"{g['share']:.0f}%") for g in genres[:limit]]
    table = format_table(["Genre", "Books", "Pages", "Share"], rows, [18, 5, 8, 5], ["l", "r", "r", "r"])
    if len(genres) > limit:
        table += f"\n(+{len(genres) - limit} more genres)"
    return table


def authors_text(authors) -> str:
    rows = [(a["author"], a["books"], f"{a['pages']:,}") for a in authors]
    return format_table(["Author", "Books", "Pages"], rows, [28, 5, 8], ["l", "r", "r"])


def ratings_text(dist) -> str:
    peak = max(dist.values()) or 1
    return "\n".join(
        f"{star} star{'s' if star > 1 else ' '} | {'#' * round(count / peak * 30):<30} {count}"
        for star, count in sorted(dist.items(), reverse=True)
    )


def alerts_text(alerts) -> str:
    if not alerts:
        return "No alerts."
    return "\n".join(f"[{a.level}] {a.message}" for a in alerts)


def books_text(books) -> str:
    rows = [
        (b.id, b.title, b.author, b.genre, f"{b.pages:,}", b.date_finished, f"{b.rating}/5")
        for b in sorted(books, key=lambda b: (b.date_finished, b.id))
    ]
    return format_table(
        ["ID", "Title", "Author", "Genre", "Pages", "Finished", "Rate"],
        rows,
        [3, 34, 22, 16, 6, 10, 4],
        ["r", "l", "l", "l", "r", "l", "r"],
    )


def summary_text(books, settings, today: date | None = None) -> str:
    """Everything the console 'Summary report' screen shows."""
    s = analytics.summary(books)
    monthly = analytics.monthly_totals(books)
    parts = [
        _section("KEY METRICS", metrics_text(s)),
        _section("MONTHLY TOTALS", monthly_text(monthly, settings, limit=12)),
        _section("GENRES", genre_text(analytics.genre_breakdown(books))),
        _section("TOP AUTHORS", authors_text(analytics.author_breakdown(books))),
        _section("RATINGS", ratings_text(analytics.rating_distribution(books))),
        _section("TREND", trend_sentence(analytics.trend(monthly, today))),
        _section("ALERTS", alerts_text(analytics.warnings(books, settings, today))),
    ]
    return "\n\n".join(parts)


# ------------------------------------------------------------------- exports
def render_audit_log(books, settings, today: date) -> str:
    header = (
        "BOOK READING STATISTICS - AUDIT LOG\n"
        f"Generated: {datetime.now().isoformat(timespec='seconds')}\n"
        f"Reference date: {today.isoformat()}\n"
    )
    full = _section("FULL MONTHLY TOTALS", monthly_text(analytics.monthly_totals(books), settings))
    return "\n\n".join([header, summary_text(books, settings, today), full, _section("ALL ENTRIES", books_text(books))]) + "\n"


def render_markdown(books, settings, today: date, chart_files=()) -> str:
    s = analytics.summary(books)
    monthly = analytics.monthly_totals(books)
    out = [
        "# Book Reading Statistics Report",
        f"_Generated {datetime.now().strftime('%Y-%m-%d %H:%M')} (data up to {s['last_date']})_",
        "",
        "## Key metrics",
        md_table(["Metric", "Value"], metrics_rows(s)),
        "",
        "## Monthly totals",
        md_table(MONTH_HEADERS, _monthly_rows(monthly, settings), MONTH_ALIGNS),
        f"\nGoal: {settings['monthly_goal_books']} book(s) and {settings['monthly_goal_pages']:,} pages per month.",
        "",
        "## Trend",
        trend_sentence(analytics.trend(monthly, today)),
        "",
        "## Genres",
        md_table(
            ["Genre", "Books", "Pages", "Share"],
            [(g["genre"], g["books"], f"{g['pages']:,}", f"{g['share']:.0f}%") for g in analytics.genre_breakdown(books)],
            ["l", "r", "r", "r"],
        ),
        "",
        "## Top authors",
        md_table(
            ["Author", "Books", "Pages"],
            [(a["author"], a["books"], f"{a['pages']:,}") for a in analytics.author_breakdown(books)],
            ["l", "r", "r"],
        ),
        "",
        "## Alerts",
    ]
    alerts = analytics.warnings(books, settings, today)
    out += [f"- **{a.level}** {a.message}" for a in alerts] or ["- No alerts."]
    if chart_files:
        out += ["", "## Charts"]
        out += [f"![{Path(f).stem.replace('_', ' ')}]({Path(f).name})" for f in chart_files]
    out += [
        "",
        "## All entries",
        md_table(
            ["ID", "Title", "Author", "Genre", "Pages", "Finished", "Rating"],
            [
                (b.id, b.title, b.author, b.genre, f"{b.pages:,}", b.date_finished, b.rating)
                for b in sorted(books, key=lambda b: (b.date_finished, b.id))
            ],
            ["r", "l", "l", "l", "r", "l", "r"],
        ),
    ]
    return "\n".join(out) + "\n"


def export_all(books, settings, out_root, today: date | None = None):
    """Write Markdown, audit log, two CSVs and charts into a new timestamped folder.

    Returns (folder, [files], chart_note) where chart_note is None or a message
    explaining why charts were skipped.
    """
    if not books:
        raise ValueError("There are no books to export yet.")
    today = today or date.today()
    folder = Path(out_root) / f"report_{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    folder.mkdir(parents=True, exist_ok=True)

    charts, chart_note = [], None
    try:
        charts = plotting.generate_all(books, folder)
    except plotting.PlottingUnavailable as exc:
        chart_note = str(exc)

    files = []

    def write_text(name, text):
        path = folder / name
        path.write_text(text, encoding="utf-8")
        files.append(path)

    write_text("report.md", render_markdown(books, settings, today, charts))
    write_text("audit_log.txt", render_audit_log(books, settings, today))

    # utf-8-sig so Excel on Windows shows accented characters correctly
    path = folder / "books.csv"
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(FIELDS)
        for b in sorted(books, key=lambda b: b.id):
            writer.writerow([b.to_dict()[f] for f in FIELDS])
    files.append(path)

    path = folder / "monthly_summary.csv"
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["month", "books", "pages", "avg_rating", "goal_status"])
        for r in analytics.monthly_totals(books):
            writer.writerow([r["month"], r["books"], r["pages"], r["avg_rating"] if r["avg_rating"] is not None else "", analytics.goal_status(r, settings)])
    files.append(path)

    return folder, files + charts, chart_note
