"""Local persistence (JSON store, CSV import) with corruption handling."""

from __future__ import annotations

import csv
import json
import os
import shutil
import tempfile
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path

from .models import Book
from .validation import ValidationError, validate_int, validate_record

SCHEMA_VERSION = 1
MAX_IMPORT_BYTES = 5 * 1024 * 1024
MAX_IMPORT_ROWS = 5000
REQUIRED_COLUMNS = ("title", "author", "genre", "pages", "date_finished", "rating")

DEFAULT_SETTINGS = {"monthly_goal_books": 2, "monthly_goal_pages": 500}
SETTING_LIMITS = {
    "monthly_goal_books": (1, 100),
    "monthly_goal_pages": (1, 100_000),
}


class StorageError(Exception):
    """A file problem the user should be told about (not a program bug)."""


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def next_id(books) -> int:
    return max((b.id for b in books), default=0) + 1


def merge_books(existing: list[Book], new: list[Book]) -> list[Book]:
    """Append `new` to `existing`, giving each a fresh unique ID."""
    merged = list(existing)
    for book in new:
        book.id = next_id(merged)
        merged.append(book)
    return merged


class Storage:
    def __init__(self, data_dir="data", today: date | None = None):
        self.data_dir = Path(data_dir)
        self.books_path = self.data_dir / "books.json"
        self.settings_path = self.data_dir / "settings.json"
        self.notices: list[str] = []
        self._today = today

    # ------------------------------------------------------------ helpers
    def _ensure_dir(self) -> None:
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise StorageError(f"Cannot create data folder {self.data_dir}: {exc}") from exc

    def _write_json_atomic(self, path: Path, payload) -> None:
        """Write to a temp file then rename, so a crash never leaves half a file."""
        self._ensure_dir()
        tmp_name = None
        try:
            with tempfile.NamedTemporaryFile(
                "w", encoding="utf-8", dir=self.data_dir, suffix=".tmp", delete=False
            ) as tmp:
                tmp_name = tmp.name
                json.dump(payload, tmp, indent=2, ensure_ascii=False)
            os.replace(tmp_name, path)
        except OSError as exc:
            if tmp_name and os.path.exists(tmp_name):
                os.unlink(tmp_name)
            raise StorageError(f"Could not save {path.name}: {exc}") from exc

    def _quarantine(self, path: Path, reason: str) -> None:
        target = path.with_name(f"{path.stem}.corrupt-{_stamp()}{path.suffix}")
        try:
            path.rename(target)
        except OSError as exc:
            raise StorageError(f"{path.name} is unreadable and could not be moved: {exc}") from exc
        self.notices.append(
            f"{path.name} was {reason}. It was kept as {target.name} and a fresh file was created."
        )

    # -------------------------------------------------------------- books
    def load_books(self) -> list[Book]:
        self.notices.clear()
        self._ensure_dir()
        try:
            raw = json.loads(self.books_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            self.save_books([])
            return []
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._quarantine(self.books_path, "corrupted (not valid JSON)")
            self.save_books([])
            return []
        except OSError as exc:
            raise StorageError(f"Cannot read {self.books_path}: {exc}") from exc

        records = raw.get("books") if isinstance(raw, dict) else raw
        if not isinstance(records, list):
            self._quarantine(self.books_path, "in an unexpected format")
            self.save_books([])
            return []

        books, used_ids, skipped = [], set(), 0
        for index, record in enumerate(records, start=1):
            clean, errors = validate_record(record, self._today)
            if errors:
                skipped += 1
                if skipped <= 5:
                    self.notices.append(f"Skipped record #{index}: {'; '.join(errors)}")
                continue
            rid = record.get("id")
            valid_id = isinstance(rid, int) and not isinstance(rid, bool) and rid > 0
            if valid_id and rid not in used_ids:
                used_ids.add(rid)
                books.append(Book.from_clean(clean, rid))
            else:
                books.append(Book.from_clean(clean, 0))
        for book in books:  # give IDs to records that had none / duplicates
            if book.id == 0:
                book.id = max(used_ids, default=0) + 1
                used_ids.add(book.id)
        if skipped:
            backup = self.books_path.with_name(f"books.skipped-{_stamp()}.json")
            try:
                shutil.copy2(self.books_path, backup)
                self.notices.append(
                    f"{skipped} invalid record(s) were skipped. Original file backed up as {backup.name}."
                )
            except OSError:
                self.notices.append(f"{skipped} invalid record(s) were skipped.")
        return books

    def save_books(self, books) -> None:
        payload = {
            "schema_version": SCHEMA_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "books": [b.to_dict() for b in books],
        }
        self._write_json_atomic(self.books_path, payload)

    # ----------------------------------------------------------- settings
    def load_settings(self) -> dict:
        settings = dict(DEFAULT_SETTINGS)
        try:
            raw = json.loads(self.settings_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            self.save_settings(settings)
            return settings
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._quarantine(self.settings_path, "corrupted (not valid JSON)")
            self.save_settings(settings)
            return settings
        except OSError as exc:
            raise StorageError(f"Cannot read {self.settings_path}: {exc}") from exc
        if isinstance(raw, dict):
            for key, (lo, hi) in SETTING_LIMITS.items():
                if key in raw:
                    try:
                        settings[key] = validate_int(raw[key], key, lo, hi)
                    except ValidationError:
                        self.notices.append(f"Setting {key} was invalid; default restored.")
        return settings

    def save_settings(self, settings: dict) -> None:
        self._write_json_atomic(self.settings_path, settings)


# --------------------------------------------------------------- CSV import
@dataclass
class RowError:
    line: int
    message: str


@dataclass
class ImportResult:
    source: str
    total_rows: int = 0
    valid: list[Book] = field(default_factory=list)
    errors: list[RowError] = field(default_factory=list)
    duplicates: list[RowError] = field(default_factory=list)


def _dup_key(title: str, author: str, finished: str):
    return (title.casefold(), author.casefold(), finished)


def import_csv(path, existing=(), today: date | None = None) -> ImportResult:
    """Validate a legacy CSV row by row. Does not modify anything on disk."""
    path = Path(path)
    try:
        if path.stat().st_size > MAX_IMPORT_BYTES:
            raise StorageError(f"{path.name} is larger than {MAX_IMPORT_BYTES // 1024 // 1024} MB.")
        handle = path.open("r", encoding="utf-8-sig", newline="")
    except FileNotFoundError as exc:
        raise StorageError(f"File not found: {path}") from exc
    except OSError as exc:
        raise StorageError(f"Cannot open {path}: {exc}") from exc

    result = ImportResult(source=str(path))
    seen = {_dup_key(b.title, b.author, b.date_finished) for b in existing}
    try:
        with handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                raise StorageError("The CSV file is empty (no header row).")
            header = {
                name: (name or "").strip().lower().replace(" ", "_")
                for name in reader.fieldnames
            }
            missing = [c for c in REQUIRED_COLUMNS if c not in header.values()]
            if missing:
                raise StorageError(
                    "CSV is missing required column(s): "
                    + ", ".join(missing)
                    + ". Expected: "
                    + ", ".join(REQUIRED_COLUMNS)
                    + "."
                )
            for row in reader:
                line = reader.line_num
                if not any((v or "").strip() for k, v in row.items() if k is not None):
                    continue  # blank line
                result.total_rows += 1
                if result.total_rows > MAX_IMPORT_ROWS:
                    raise StorageError(f"Too many rows (limit {MAX_IMPORT_ROWS}).")
                if None in row:
                    result.errors.append(RowError(line, "Row has more columns than the header."))
                    continue
                raw = {header[name]: value for name, value in row.items()}
                clean, errors = validate_record(raw, today)
                if errors:
                    result.errors.append(RowError(line, "; ".join(errors)))
                    continue
                key = _dup_key(clean["title"], clean["author"], clean["date_finished"])
                if key in seen:
                    result.duplicates.append(
                        RowError(line, f"Duplicate of an existing entry: '{clean['title']}'.")
                    )
                    continue
                seen.add(key)
                result.valid.append(Book.from_clean(clean))
    except UnicodeDecodeError as exc:
        raise StorageError("The file is not valid UTF-8 text. Re-save it as CSV (UTF-8).") from exc
    except csv.Error as exc:
        raise StorageError(f"The file is not a readable CSV: {exc}") from exc
    return result


def write_error_log(result: ImportResult, out_dir) -> Path:
    out_dir = Path(out_dir)
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"import_errors_{_stamp()}.log"
        lines = [
            f"Import error log for {result.source}",
            f"Generated: {datetime.now().isoformat(timespec='seconds')}",
            f"Rows read: {result.total_rows} | valid: {len(result.valid)} | "
            f"duplicates: {len(result.duplicates)} | rejected: {len(result.errors)}",
            "",
        ]
        lines += [f"Line {e.line}: REJECTED - {e.message}" for e in result.errors]
        lines += [f"Line {e.line}: SKIPPED  - {e.message}" for e in result.duplicates]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except OSError as exc:
        raise StorageError(f"Could not write the error log: {exc}") from exc
    return path
