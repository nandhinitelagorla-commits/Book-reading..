#!/usr/bin/env python3
"""Book Reading Statistics - entry point.

    python main.py                 start the interactive menu
    python main.py --load-sample   load the bundled 41-book dataset first
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from brs import APP_NAME, __version__, ui
from brs.cli import SAMPLE_CSV, App
from brs.storage import StorageError

ROOT = Path(__file__).resolve().parent


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=f"{APP_NAME} - track books, pages, genres and monthly totals.")
    parser.add_argument("--data-dir", default=str(ROOT / "data"), help="where books.json / settings.json live")
    parser.add_argument("--export-dir", default=str(ROOT / "exports"), help="where reports and charts are written")
    parser.add_argument("--load-sample", action="store_true", help="import sample_data/sample_books.csv if no books exist yet")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} {__version__}")
    return parser.parse_args(argv)


def main(argv=None) -> int:
    if sys.version_info < (3, 10):
        print("Python 3.10 or newer is required.")
        return 1
    args = parse_args(argv)
    ui.enable_ansi()
    try:
        app = App(data_dir=args.data_dir, export_dir=args.export_dir)
        if args.load_sample:
            if app.books:
                ui.info("Data already exists - skipping --load-sample.")
            elif not SAMPLE_CSV.is_file():
                ui.error(f"Sample file not found: {SAMPLE_CSV}")
            else:
                result, _ = app.import_file(SAMPLE_CSV)
                ui.success(f"Loaded {len(result.valid)} sample book(s).")
        app.run()
    except StorageError as exc:
        ui.error(str(exc))
        return 1
    except (EOFError, KeyboardInterrupt):
        print("\nInput closed. Your data is already saved. Goodbye!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
